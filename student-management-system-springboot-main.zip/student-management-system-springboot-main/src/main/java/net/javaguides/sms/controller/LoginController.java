package net.javaguides.sms.controller;

import java.util.Objects;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import net.javaguides.sms.entity.Logindomain;
import net.javaguides.sms.service.Loginservice;
@Controller
public class LoginController {
    
    @Autowired
    private Loginservice userService;
                                   
    @GetMapping("/login")      
    public ModelAndView login() {
        ModelAndView mav = new ModelAndView("login");
        mav.addObject("user", new Logindomain());
        return mav;
    }
    @PostMapping("/login")
    public String login(@ModelAttribute("user") Logindomain user ) {
        
        Logindomain oauthUser = userService.login(user.getUsername(), user.getPassword());
        
        System.out.print(oauthUser);
        if(Objects.nonNull(oauthUser)) 
        {    
  
            return "redirect:/students";
        
            
        } else {
            return "redirect:/login";
            
        
        }
}
    
    /*@RequestMapping(value = {"/logout"}, method = RequestMethod.POST)
    public String logoutDo(HttpServletRequest request,HttpServletResponse response)
    {
        
      
        return "redirect:/login";
    }*/
    @RequestMapping(value = {"/logout"}, method = RequestMethod.POST)
    public String logoutDo() {
        // No need to use HttpServletRequest and HttpServletResponse in this method.
        // Redirect to login page after logout.
        return "redirect:/login";
    }
    
    @GetMapping("/create_teacher")
    public ModelAndView teacherRegistration() {
        ModelAndView mav = new ModelAndView("create_teacher");
        mav.addObject("teacher", new Logindomain());  
        return mav;
    }
    
    @PostMapping("/register-teacher")
    public String registerTeacher(@ModelAttribute("teacher") Logindomain teacher) {
        userService.saveTeacher(teacher);
        return "redirect:/login";  
    }
    
    @GetMapping("/home")  // Optional: Maps to /home URL
    public String showHomePageAgain() {
        return "home";  // Load home.html from src/main/resources/templates
    }
    
    @GetMapping("/about")
    public String showAboutPage() {
        return "about";  // This will load about.html from src/main/resources/templates
    }

    @GetMapping("/contact")
    public String showContactPage() {
        return "contact";  // This will load contact.html from src/main/resources/templates
    }

    
    
    
    
    
    
    
    
}