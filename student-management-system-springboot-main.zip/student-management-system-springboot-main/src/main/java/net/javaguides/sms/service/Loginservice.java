package net.javaguides.sms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import net.javaguides.sms.entity.Logindomain;
import net.javaguides.sms.entity.Student;
import net.javaguides.sms.repository.LoginRepository;

@Service
public class Loginservice {
    
    @Autowired
    private LoginRepository repo;
  
    public Logindomain login(String username, String password) {
      Logindomain user = repo.findByUsernameAndPassword(username, password);
      return user;
    }
   
	public Logindomain saveTeacher(Logindomain teacher) {
        return repo.save(teacher);
    }

	
	
    
    
    
    
    
    
}
 
