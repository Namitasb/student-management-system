package net.javaguides.sms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import net.javaguides.sms.entity.Logindomain;

@Repository
public interface LoginRepository extends JpaRepository<Logindomain, Long>{
    Logindomain findByUsernameAndPassword(String username, String password);
}
